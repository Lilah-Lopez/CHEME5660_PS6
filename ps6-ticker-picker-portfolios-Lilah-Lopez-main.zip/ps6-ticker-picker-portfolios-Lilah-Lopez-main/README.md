[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/CIhCnyOM)
# PS6-CHEME-5600-TEMPLATE-Fall-2024
Template for Problem Set 6 for CHEME 5660 Fall 2024
