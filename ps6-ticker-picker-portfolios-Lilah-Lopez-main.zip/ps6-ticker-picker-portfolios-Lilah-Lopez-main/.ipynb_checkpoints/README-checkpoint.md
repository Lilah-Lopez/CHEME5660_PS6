# PS6-CHEME-5600-TEMPLATE-Fall-2024
Template for Problem Set 6 for CHEME 5660 Fall 2024
